package utility;

   public class Constant {

      public static final String URL = "http://www.autozone.com";

      public static final String Username = "rudra200519@gmail.com";

      public static final String Password = "test@121";

      public static final String Path_TestData = "C:\\Users\\Administrator\\Framework\\Web\\src\\main\\java\\testData\\";

      public static final String File_TestData = "TestData.xlsx";

   }